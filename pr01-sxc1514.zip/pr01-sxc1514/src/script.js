$(document).ready(function () {
  console.log("ready!");
});
<!-- calculating costs -->
function calculate(){
  let begin = document.getElementById("start").value;
  console.log(begin);
  let begin_moment = moment(begin);
  let finish = document.getElementById("end").value;
  let finish_moment = moment(finish);
  let difference= finish_moment.diff(begin_moment,'days');
  $("#days").val(difference);
  let adults = document.getElementById("adultselected").value;
  $("#totalCost").val(difference*adults*150);
  
}

function resetForm(){
  console.log("reset");
  document.getElementById('form').reset;
  
  let user = document.getElementById('username');
  user.classList.remove("has-error");
  
  let first = document.getElementById('firstname');
  first.classList.remove("has-error");
  
  let last = document.getElementById('lastname');
  last.classList.remove("has-error");
  
  let phone = document.getElementById('phone');
  phone.classList.remove("has-error");
  
  let fax = document.getElementById('fax');
  fax.classList.remove("has-error");
  
  let email = document.getElementById('email');
  email.classList.remove("has-error");
  
  toastr.info("Reset");
}

function validate() {
  let valid = true; 
  if (document.getElementById("usernameInput").value === "") {
    $("#username").addClass("has-error");
    toastr.error("No username", "Username");
    valid = false;
    //console.log("Error");
  }else{
    $("#username").removeClass("has-error");
  }
  
  if (document.getElementById("firstnameInput").value === "") {
    $("#firstname").addClass("has-error");
    toastr.error("No firstname", "Firstname");
    console.log("Error");
    valid = false;
  }
  else{
    $("#firstname").removeClass("has-error");
  }
  
  
  if (document.getElementById("lastnameInput").value === "") {
    $("#lastname").addClass("has-error");
    toastr.error("No lastname", "Lastname");
    console.log("Error");
    valid= false;
  }else{
    $("#lastname").removeClass("has-error");
  }
  
  if (document.getElementById("phoneInput").value === "") {
    $("#phone").addClass("has-error");
    toastr.error("No Phone number", "Phone number");
    console.log("Error");
    valid = false;
  }else{
    $("#phone").removeClass("has-error");
  }
  
  if (document.getElementById("faxInput").value === "") {
    $("#fax").addClass("has-error");
    toastr.error("No fax", "Fax");
    console.log("Error");
    valid = false;
  }else{
    $("#fax").removeClass("has-error");
  }
  
  if (document.getElementById("emailInput").value === "") {
    $("#email").addClass("has-error");
    toastr.error("No email", "Email");
    console.log("Error");
    valid = false;
  }else{
    $("#email").removeClass("has-error");
  }
  
  if(!$('#totalCost').val()){
    toastr.error("No Cost Calculated", "Cost Error");
    valid = false;
  }
  
  if($('#totalCost').val()<0){
    toastr.error("Negative Cost", "Cost Error");
    valid = false;
  }
  
  if(valid){
    toastr.success("Form Submitted","Success");
  }
}
